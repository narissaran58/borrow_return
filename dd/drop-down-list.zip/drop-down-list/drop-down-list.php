<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>PHP Insert Drop Down List selected value in MySQL database</title>
</head>

<body>

<form method="post" action="">
 
 <label >Please Select Subject</label>
 
 <select name="subject_names">
 <option>---Select Subject--</option>
 <option value="Android">Android</option>
 <option value="PHP">PHP</option>
 <option value="Java">Java</option>
 <option value="JavaScript">JavaScript</option>
 <option value="Maths">Maths</option>
 
 </select>

 <button type="submit" name="submit" >Submit</button>
 
 </form>

<?php
if(isset($_POST["submit"]))
{
 
 //Including dbconfig file.
include 'dbconfig.php';
 
$subjectName=$_POST["subject_names"];

mysql_query("INSERT INTO demo_table_6 (subject) VALUES ('$subjectName')"); 

echo " Added Successfully ";

}

 ?>

</body>
</html>