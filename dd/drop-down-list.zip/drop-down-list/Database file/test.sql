-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2016 at 03:28 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `demo_table_5`
--

CREATE TABLE `demo_table_5` (
  `id` int(255) NOT NULL,
  `MultipleValue` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `demo_table_5`
--

INSERT INTO `demo_table_5` (`id`, `MultipleValue`) VALUES
(2, 'Laptop,Mobile,'),
(3, 'Computer,Laptop,Mobile,Tablet,'),
(4, 'Mobile,Tablet,'),
(5, 'Laptop,Mobile,Tablet,'),
(6, 'Computer,Laptop,Mobile,');

-- --------------------------------------------------------

--
-- Table structure for table `demo_table_6`
--

CREATE TABLE `demo_table_6` (
  `id` int(255) NOT NULL,
  `subject` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `demo_table_6`
--

INSERT INTO `demo_table_6` (`id`, `subject`) VALUES
(1, 'PHP'),
(2, 'JavaScript'),
(3, 'Android'),
(4, 'Java'),
(5, 'Maths');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `demo_table_5`
--
ALTER TABLE `demo_table_5`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `demo_table_6`
--
ALTER TABLE `demo_table_6`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `demo_table_5`
--
ALTER TABLE `demo_table_5`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `demo_table_6`
--
ALTER TABLE `demo_table_6`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
